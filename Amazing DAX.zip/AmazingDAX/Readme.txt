Thank you for downloading our aMAZE-ing DAX game...

To modify the levels of the game you must edit the CSV files in the Maps folder.
Walls are denoted with "x", the location of the insight is marked with an "i"

To Refresh the data:
The PBIX file A MAZE-ing DAX file has a parameter for the folder location.
Move the Maps and Sprites folders to the following location "C:\AmazingDAX"  
The parameter inside the PBIX file is called FolderLocation.  
If you want to move the Maps / Sprites to a new location you must adjust the FolderLocation paramter.

Enjoy the Game.  Please share it on social media..

Thanks,
Mike, Seth, and Phil 
PowerBI.Tips